# Autenticacao com JWT

API de autenticacao com cadastro, login, geracao e validacao de tokens JWT.

## Executar

```bash
npm install
cp .env.example .env
npm start
```

Defina `JWT_SECRET` com uma chave longa e aleatoria antes de usar a API. Os usuarios ficam em memoria nesta versao, portanto sao perdidos quando o processo reinicia.

## Endpoints

- `POST /auth/register` - recebe `name`, `email` e `password` (minimo de 6 caracteres).
- `POST /auth/login` - recebe `email` e `password`, retornando `token`.
- `GET /auth/me` - exige `Authorization: Bearer <token>`.
- `GET /health` - verifica se a API esta ativa.

Para executar os testes:

```bash
npm test
```
