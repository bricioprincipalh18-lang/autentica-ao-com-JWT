process.env.JWT_SECRET = 'segredo-de-teste';

const test = require('node:test');
const assert = require('node:assert/strict');
const { app, users } = require('../src/server');

let server;
let baseUrl;

test.before(() => {
  server = app.listen(0);
  const { port } = server.address();
  baseUrl = `http://127.0.0.1:${port}`;
});

test.after(() => server.close());
test.beforeEach(() => users.clear());

async function request(path, options = {}) {
  return fetch(`${baseUrl}${path}`, {
    headers: { 'content-type': 'application/json', ...options.headers },
    ...options
  });
}

test('cadastra, autentica e acessa rota protegida', async () => {
  const registration = await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name: 'Ada', email: 'ADA@example.com', password: 'segredo123' })
  });
  assert.equal(registration.status, 201);

  const login = await request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: 'ada@example.com', password: 'segredo123' })
  });
  assert.equal(login.status, 200);
  const { token } = await login.json();
  assert.ok(token);

  const profile = await request('/auth/me', {
    headers: { authorization: `Bearer ${token}` }
  });
  assert.equal(profile.status, 200);
  assert.equal((await profile.json()).user.email, 'ada@example.com');
});

test('rejeita senha incorreta e acesso sem token', async () => {
  await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ name: 'Ada', email: 'ada@example.com', password: 'segredo123' })
  });

  const login = await request('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: 'ada@example.com', password: 'errada1' })
  });
  assert.equal(login.status, 401);

  const profile = await request('/auth/me');
  assert.equal(profile.status, 401);
});