require('dotenv').config();

const { randomUUID } = require('node:crypto');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const users = new Map();
const port = Number(process.env.PORT || 3000);
const jwtSecret = process.env.JWT_SECRET;
const jwtExpiresIn = process.env.JWT_EXPIRES_IN || '1h';

if (!jwtSecret) {
  throw new Error('JWT_SECRET nao foi configurado. Defina-o no ambiente antes de iniciar a API.');
}

app.use(express.json());

function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email };
}

function authenticateToken(request, response, next) {
  const authorization = request.headers.authorization;
  const [scheme, token] = authorization ? authorization.split(' ') : [];

  if (scheme !== 'Bearer' || !token) {
    return response.status(401).json({ error: 'Token de acesso ausente ou invalido' });
  }

  try {
    request.user = jwt.verify(token, jwtSecret);
    return next();
  } catch {
    return response.status(401).json({ error: 'Token de acesso invalido ou expirado' });
  }
}

app.get('/health', (request, response) => {
  response.json({ status: 'ok' });
});

app.post('/auth/register', async (request, response) => {
  const { name, email, password } = request.body || {};
  const normalizedEmail = typeof email === 'string' ? email.trim().toLowerCase() : '';

  if (!name || !normalizedEmail || typeof password !== 'string' || password.length < 6) {
    return response.status(400).json({
      error: 'Nome, email e senha com pelo menos 6 caracteres sao obrigatorios'
    });
  }

  if (users.has(normalizedEmail)) {
    return response.status(409).json({ error: 'Email ja cadastrado' });
  }

  const user = {
    id: randomUUID(),
    name: name.trim(),
    email: normalizedEmail,
    passwordHash: await bcrypt.hash(password, 12)
  };
  users.set(normalizedEmail, user);

  return response.status(201).json({ user: publicUser(user) });
});

app.post('/auth/login', async (request, response) => {
  const { email, password } = request.body || {};
  const user = users.get(typeof email === 'string' ? email.trim().toLowerCase() : '');

  if (!user || typeof password !== 'string' || !(await bcrypt.compare(password, user.passwordHash))) {
    return response.status(401).json({ error: 'Email ou senha invalidos' });
  }

  const token = jwt.sign({ sub: user.id, email: user.email }, jwtSecret, {
    expiresIn: jwtExpiresIn
  });

  return response.json({ token, user: publicUser(user) });
});

app.get('/auth/me', authenticateToken, (request, response) => {
  const user = [...users.values()].find((candidate) => candidate.id === request.user.sub);

  if (!user) {
    return response.status(404).json({ error: 'Usuario nao encontrado' });
  }

  return response.json({ user: publicUser(user) });
});

if (require.main === module) {
  app.listen(port, () => {
    console.log(`API de autenticacao executando em http://localhost:${port}`);
  });
}

module.exports = { app, users };